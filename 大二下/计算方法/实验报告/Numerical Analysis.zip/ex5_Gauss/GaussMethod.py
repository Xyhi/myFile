import numpy as np


def Gauss(A, b):
    n = b.size
    m = np.zeros((n, n))
    x = np.zeros(n)
    for k in range(n):
        item = np.max(abs(A[k:n, k]))
        p = np.argmax(abs(A[k:n, k])) + k
        if item == 0:
            return False
        if p != k:
            A[[k, p], :] = A[[p, k], :]
            b[[k, p]] = b[[p, k]]
        for i in range(k + 1, n):
            m[i, k] = A[i, k] / A[k, k]
        for i in range(k + 1, n):
            b[i] -= b[k] * m[i, k]
            for j in range(k, n):
                A[i, j] -= A[k, j] * m[i, k]
    if A[n - 1, n - 1] == 0:
        return False
    x[n - 1] = b[n - 1] / A[n - 1, n - 1]
    for k in range(n - 2, -1, -1):
        x[k] = b[k]
        for j in range(k + 1, n):
            x[k] -= A[k, j] * x[j]
        x[k] /= A[k, k]
    return x


def solve(A, b):
    x = Gauss(A, b)
    print("the result is [", end="")
    [print("%.15f " % item, end="") for item in x]
    print("]")


def main():
    print("Question1_1")
    A_1_1 = np.array([[0.4096, 0.1234, 0.3678, 0.2943],
                      [0.2246, 0.3872, 0.4015, 0.1129],
                      [0.3645, 0.1920, 0.3781, 0.0643],
                      [0.1784, 0.4002, 0.2786, 0.3927]])
    b_1_1 = np.array([1.1951, 1.1262, 0.9989, 1.2499])
    solve(A_1_1, b_1_1)

    print("Question1_2")
    A_1_2 = np.array([[136.01, 90.860, 0, 0],
                      [90.860, 98.810, -67.590, 0],
                      [0, -67.590, 132.01, 46.260],
                      [0, 0, 46.260, 177.17]])
    b_1_2 = np.array([226.87, 122.08, 110.68, 223.43])
    solve(A_1_2, b_1_2)

    print("Question1_3")
    A_1_3 = np.array([[1, 1/2, 1/3, 1/4],
                      [1/2, 1/3, 1/4, 1/5],
                      [1/3, 1/4, 1/5, 1/6],
                      [1/4, 1/5, 1/6, 1/7]])
    b_1_3 = np.array([25/12, 77/60, 57/60, 319/420])
    solve(A_1_3, b_1_3)

    print("Question1_4")
    A_1_4 = np.array([[10.0, 7.0, 8.0, 7.0],
                      [7.0, 5.0, 6.0, 5.0],
                      [8.0, 6.0, 10.0, 9.0],
                      [7.0, 5.0, 9.0, 10.0]])
    b_1_4 = np.array([32.0, 23.0, 33.0, 31.0])
    solve(A_1_4, b_1_4)
    print()

    print("Question2_1")
    A_2_1 = np.array([[197.0, 305.0, -206.0, -804.0],
                      [46.8, 71.3, -47.4, 52.0],
                      [88.6, 76.4, -10.8, 802.0],
                      [1.45, 5.90, 6.13, 36.5]])
    b_2_1 = np.array([136.0, 11.7, 25.1, 6.60])
    solve(A_2_1, b_2_1)
    print("Question2_2")
    A_2_2 = np.array([[0.5398, 0.7161, -0.5554, -0.2982],
                      [0.5257, 0.6924, 0.3565, -0.6255],
                      [0.6465, -0.8187, -0.1872, 0.1291],
                      [0.5814, 0.9400, -0.7779, -0.4042]])
    b_2_2 = np.array([0.2058, -0.0503, 0.1070, 0.1859])
    solve(A_2_2, b_2_2)
    print("Question2_3")
    A_2_3 = np.array([[10.0, 1.0, 2.0],
                      [1.0, 10.0, 2.0],
                      [1.0, 1.0, 5.0]])
    b_2_3 = np.array([13.0, 13.0, 7.0])
    solve(A_2_3, b_2_3)
    print("Question2_4")
    A_2_4 = np.array([[4.0, -2.0, -4.0],
                      [-2.0, 17.0, 10.0],
                      [-4.0, 10.0, 9.0]])
    b_2_4 = np.array([-2.0, 25.0, 15.0])
    solve(A_2_4, b_2_4)


if __name__ == '__main__':
    main()
