import numpy as np


def Lagrange(function, sample_points, data_points):
    n = sample_points.size
    function_values = []
    y = 0
    for i in range(len(data_points)):
        for k in range(n):
            l = 1
            for j in range(n):
                if j != k:
                    l *= ((data_points[i] - sample_points[j]) / (sample_points[k] - sample_points[j]))
            y += l * function(sample_points[k])
        function_values.append((data_points[i], y))
        y = 0
    return function_values


def function1(x):
    return 1 / (1 + x ** 2)


def function2(x):
    return np.exp(x)


def function3(x):
    return np.sqrt(x)


def solve(data_points, x, n, function):
    for i in range(n):
        print("When n = %d, the result is" % (5 << i))
        function_values = (Lagrange(function, x[i], data_points))
        [print("(%.2f, %.10f) " % item, end="") for item in function_values]
        print()
    print()


def solve2(data_points, x, function):
    print("The result is")
    function_values = (Lagrange(function, x, data_points))
    [print("(%.2f, %.6f) " % item, end="") for item in function_values]
    print()


def relativeError(data_points, x, function):
    print("the Error is")
    function_values = (Lagrange(function, x, data_points))
    [print("%.10f " % ((item[1] - function(item[0])) / function(item[0])), end="") for item in function_values]
    print()


def main():
    num = 3
    print("Question1_1")
    data_points_1_1 = [0.75, 1.75, 2.75, 3.75, 4.75]
    x_1_1 = []
    for i in range(num):
        x_1_1.append(np.linspace(-5, 5, (5 << i) + 1))
    solve(data_points_1_1, x_1_1, num, function1)

    print("Question1_2")
    data_points_1_2 = [-0.95, -0.05, 0.05, 0.95]
    x_1_2 = []
    for i in range(num):
        x_1_2.append(np.linspace(-1, 1, (5 << i) + 1))
    solve(data_points_1_2, x_1_2, num, function2)

    print("Question2_1")
    data_points_2_1 = [-0.95, -0.05, 0.05, 0.95]
    x_2_1 = []
    for i in range(num):
        x_2_1.append(np.linspace(-1, 1, (5 << i) + 1))
    solve(data_points_2_1, x_2_1, num, function1)

    print("Question2_2")
    data_points_2_2 = [-4.75, -0.25, 0.25, 4.75]
    x_2_2 = []
    for i in range(num):
        x_2_2.append(np.linspace(-5, 5, (5 << i) + 1))
    solve(data_points_2_2, x_2_2, num, function2)

    print("Question4_1")
    data_points_4 = [5, 50, 115, 185]
    x_4_1 = np.array([1, 4, 9])
    solve2(data_points_4, x_4_1, function3)

    print("Question4_2")
    x_4_2 = np.array([36, 49, 64])
    solve2(data_points_4, x_4_2, function3)

    print("Question4_3")
    x_4_3 = np.array([100, 121, 144])
    solve2(data_points_4, x_4_3, function3)

    print("Question4_4")
    x_4_4 = np.array([169, 196, 225])
    solve2(data_points_4, x_4_4, function3)


if __name__ == '__main__':
    main()
