import numpy as np
import sympy as sp


def Romberg(a, b, N, epsilon, f):
    h = b - a
    T = np.zeros((N, N))
    T[0, 0] = 1/2 * h * (f(a) + f(b))
    for i in range(1, N):
        T[0, i] = 1/2*T[0, i-1] + h/2*np.sum(f(a + np.arange(1, 2**i+1, 2)*h/2))
        for j in range(1, i + 1):
            T[j, i - j] = (4**j*T[j-1, i-j+1] - T[j-1, i-j])/(4**j - 1)
        if abs(T[i, 0] - T[i - 1, 0]) < epsilon:
            return T
        h /= 2
    return False


def f1(x):
    return x**2 * np.exp(x)


def f2(x):
    return np.exp(x) * np.sin(x)


def f3(x):
    return 4 / (1 + x**2)


def f4(x):
    return 1 / (x + 1)


def solve(a, b, N, epsilon, f):
    T = Romberg(a, b, N, epsilon, f)
    T = T[~(T == 0).all(1)]
    T = T[:, ~(T == 0).all(0)]
    result = T[T.shape[0] - 1][0]
    print("the result is %.8f" % result)


def main():
    x = sp.Symbol("x")

    print("Question1_1")
    a_1 = 0
    b_1 = 1
    epsilon = 1e-6
    N = 20
    solve(a_1, b_1, N, epsilon, f1)

    print("Question1_2")
    a_2 = 1
    b_2 = 3
    solve(a_2, b_2, N, epsilon, f2)

    print("Question1_3")
    a_3 = 0
    b_3 = 1
    solve(a_3, b_3, N, epsilon, f3)

    print("Question1_4")
    a_4 = 0
    b_4 = 1
    solve(a_4, b_4, N, epsilon, f4)


if __name__ == '__main__':
    main()
