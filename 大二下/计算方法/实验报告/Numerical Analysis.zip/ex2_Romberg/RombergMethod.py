import numpy as np
import sympy as sp


def Romberg(a, b, N, epsilon, f):
    h = b - a
    m = 1
    T_List = []
    T1 = 1/2 * h * (f(a) + f(b))
    T_List.append(T1)
    for i in range(1, N):
        ii = 2 ** (i - 1)
        T2 = 1/2 * T1 + 1/2*h*cal_Un(f, h, a, ii)
        S2 = 1/3 * (4*T2 - T1)
        if m == 1:
            T_List.append([T2, S2])
        elif m == 2:
            C2 = 1/15*(16*S2 - S1)
            C1 = C2
            T_List.append([T2, S2, C2])
        else:
            C2 = 1/15*(16*S2 - S1)
            R2 = 1/63*(64*C2 - C1)
            if m > 3 and abs(R2 - R1) < epsilon:
                T_List.append([T2, S2, C2, R2])
                return T_List
            C1 = C2
            R1 = R2
            T_List.append([T2, S2, C2, R2])
        T1 = T2
        S1 = S2
        h /= 2
        m += 1
    return False


def cal_Un(f, h, a, ii):
    Un = 0
    for k in range(ii):
        Un += f(a + (k + 1/2)*h)
    return Un


def f1(x):
    return x**2 * np.exp(x)


def f2(x):
    return np.exp(x) * np.sin(x)


def f3(x):
    return 4 / (1 + x**2)


def f4(x):
    return 1 / (x + 1)


def solve(a, b, N, epsilon, f):
    T_List = Romberg(a, b, N, epsilon, f)
    n = len(T_List)
    m = len(T_List[n - 1])
    result = T_List[n - 1][m - 1]
    print("the result is %.8f" % result)


def main():
    x = sp.Symbol("x")

    print("Question1_1")
    a_1 = 0
    b_1 = 1
    epsilon = 1e-6
    N = 100
    solve(a_1, b_1, N, epsilon, f1)

    print("Question1_2")
    a_2 = 1
    b_2 = 3
    solve(a_2, b_2, N, epsilon, f2)

    print("Question1_3")
    a_3 = 0
    b_3 = 1
    solve(a_3, b_3, N, epsilon, f3)

    print("Question1_4")
    a_4 = 0
    b_4 = 1
    solve(a_4, b_4, N, epsilon, f4)


if __name__ == '__main__':
    main()
