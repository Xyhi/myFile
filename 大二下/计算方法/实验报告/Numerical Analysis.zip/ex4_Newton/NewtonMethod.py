import sympy as sp


def Newton(function, x0, epsilon1, epsilon2, N):
    n = 1
    x = sp.Symbol("x")
    while n <= N:
        F = function(x0)
        DF = sp.diff(function(x), x).evalf(subs={x: x0})
        if abs(F) < epsilon1:
            return x0
        if abs(DF) < epsilon2:
            return False
        x1 = x0 - F / DF
        Tol = abs(x1 - x0)
        if Tol < epsilon1:
            return x1
        n = n + 1
        x0 = x1
    return False


def function1(x):
    return sp.cos(x) - x


def function2(x):
    return sp.exp(-x) - sp.sin(x)


def function3(x):
    return x - sp.exp(-x)


def function4(x):
    return x ** 2 - 2*x*sp.exp(-x) + sp.exp(-2 * x)


def main():
    epsilon1 = 1e-6
    epsilon2 = 1e-4
    N = 10
    x0_1 = sp.pi / 4
    x0_2 = 0.6
    x0_3 = 0.5
    x0_4 = 0.5
    print("Question1_1")
    ret1_1 = Newton(function1, x0_1, epsilon1, epsilon2, N)
    print("the approximate root is %f" % ret1_1)
    print("Question1_2")
    ret1_2 = Newton(function2, x0_2, epsilon1, epsilon2, N)
    print("the approximate root is %f" % ret1_2)
    print("Question2_1")
    ret2_1 = Newton(function3, x0_3, epsilon1, epsilon2, N)
    print("the approximate root is %f" % ret2_1)
    print("Question2_2")
    ret2_2 = Newton(function4, x0_4, epsilon1, epsilon2, 2 * N)
    print("the approximate root is %f" % ret2_2)


if __name__ == '__main__':
    main()
