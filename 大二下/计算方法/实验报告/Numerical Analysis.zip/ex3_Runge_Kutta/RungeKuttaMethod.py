import sympy as sp
import numpy as np

x, y = sp.symbols('x y')


def RungeKutta(a, b, alpha, N, function):
    x0 = a
    y0 = alpha
    h = (b - a) / N
    X = np.zeros(N)
    Y = np.zeros(N)
    for i in range(N):
        K1 = h * function.subs({x: x0, y: y0})
        K2 = h * function.subs({x: x0+h/2, y: y0+1/2*K1})
        K3 = h * function.subs({x: x0+h/2, y: y0+1/2*K2})
        K4 = h * function.subs({x: x0+h, y: y0+K3})
        X[i] = x0 + h
        Y[i] = y0 + 1/6*(K1 + 2*K2 + 2*K3 + K4)
        x0 = X[i]
        y0 = Y[i]
    return X, Y


def function1(x, y):
    return x + y


def function2(x, y):
    return -y**2


def function3(x, y):
    return 2*y/x + x*x*sp.exp(x)


def function4(x, y):
    return 1/x*(y**2 + y)


def function5(x, y):
    return -20*(y-x**2) + 2*x


def function6(x, y):
    return -20*y + 20*sp.sin(x) + sp.cos(x)


def function7(x, y):
    return -20*(y-sp.exp(x)*sp.sin(x)) + sp.exp(x)*(sp.sin(x) + sp.cos(x))


def solve(a, b, alpha, N, function, num):
    for i in range(num):
        print("When N = %d, the result is" % (5 << i))
        X, Y = RungeKutta(a, b, alpha, N << i, function)
        [print("(%.2f, %.10f) " % (X[i], Y[i])) for i in range(X.size)]
    print()


def main():
    num = 3
    N = 5
    print("Question1_1")
    solve(0, 1, -1, N, function1(x, y), num)
    print("Question1_2")
    solve(0, 1, 1, N, function2(x, y), num)
    print("Question2_1")
    solve(1, 3, 0, N, function3(x, y), num)
    print("Question2_2")
    solve(1, 3, -2, N, function4(x, y), num)
    print("Question3_1")
    solve(0, 1, 1/3, N, function5(x, y), num)
    print("Question3_2")
    solve(0, 1, 1, N, function6(x, y), num)
    print("Question3_3")
    solve(0, 1, 0, N, function7(x, y), num)


if __name__ == '__main__':
    main()
