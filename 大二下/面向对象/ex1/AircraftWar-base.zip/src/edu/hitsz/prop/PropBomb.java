package edu.hitsz.prop;

import edu.hitsz.aircraft.AbstractAircraft;

/**
 * @author xyhstart
 * @create 2022-03-15 8:54
 */
public class PropBomb extends AbstractProp{

    public PropBomb(int locationX, int locationY) {
        super(locationX, locationY);
    }

    /**
     * 测试炸弹道具功能
     * @param abstractAircrafts
     */
    @Override
    public void function(AbstractAircraft... abstractAircrafts) {
        if(abstractAircrafts == null) {
            System.out.println("BombSupply active!");
        }
        vanish();
    }
}
