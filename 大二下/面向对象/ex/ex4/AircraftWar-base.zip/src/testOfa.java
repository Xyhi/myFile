import edu.hitsz.DAO.DataDAOImpl;

import java.io.IOException;

/**
 * @author xyhstart
 * @create 2022-04-09 21:52
 */
public class testOfa {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        DataDAOImpl dataDAO = new DataDAOImpl();
        dataDAO.dispAllData();
    }
}
