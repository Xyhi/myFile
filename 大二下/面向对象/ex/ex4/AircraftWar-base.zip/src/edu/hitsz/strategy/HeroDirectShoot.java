package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;
import edu.hitsz.bullet.HeroBullet;

import java.util.LinkedList;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-04-09 17:20
 */
public class HeroDirectShoot implements ShootStrategy{
    @Override
    public List<BaseBullet> shoot(int locationX, int locationY, int shootNum, int direction, int power)  {
        List<BaseBullet> res = new LinkedList<>();
        int x = locationX;
        int y = locationY + direction*2;
        int speedX = 0;
        int speedY = direction*5;
        BaseBullet baseBullet;
        baseBullet = new HeroBullet(x, y, speedX, speedY, power);
        res.add(baseBullet);
        return res;
    }
}
