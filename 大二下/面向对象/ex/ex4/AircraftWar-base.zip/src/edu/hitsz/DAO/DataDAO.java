package edu.hitsz.DAO;

import java.io.IOException;
import java.util.List;

/**
 * 考虑到课程内容，此次使用IO对象处理流来实现控制台输出得分列表功能
 * @author xyhstart
 * @create 2022-04-09 20:21
 */
public interface DataDAO {

    List<Data> getAllData() throws IOException, ClassNotFoundException;

    void addData(Data data) throws IOException, ClassNotFoundException;

    void deleteData(int dataId);

    void dispAllData() throws IOException, ClassNotFoundException;
}
