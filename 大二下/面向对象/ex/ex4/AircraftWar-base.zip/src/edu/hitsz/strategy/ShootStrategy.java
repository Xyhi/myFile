package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-04-08 21:22
 */
public interface ShootStrategy {
    List<BaseBullet> shoot(int locationX, int locationY, int shootNum, int direction, int power);
}
