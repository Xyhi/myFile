package edu.hitsz.aircraft;

import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.strategy.ShootStrategy;

import java.util.List;

/**
 * 英雄飞机，游戏玩家操控
 * @author hitsz
 */
public class HeroAircraft extends AbstractAircraft {
    /** 单例模式*/
    private volatile static HeroAircraft heroAircraft;

    /** 攻击方式 */
    private int shootNum = 1;     //子弹一次发射数量
    private int power = 3000;       //子弹伤害
    private int direction = -1;   //子弹射击方向 (向上发射：1，向下发射：-1)

    /** 定义策略 */
    private ShootStrategy shootStrategy;

    /**
     * 单例模式私有化构造器
     * @param locationX 英雄机位置x坐标
     * @param locationY 英雄机位置y坐标
     * @param speedX 英雄机射出的子弹的基准速度（英雄机无特定速度）
     * @param speedY 英雄机射出的子弹的基准速度（英雄机无特定速度）
     * @param hp    初始生命值
     */
    private HeroAircraft(int locationX, int locationY, int speedX, int speedY, int hp, ShootStrategy shootStrategy) {
        super(locationX, locationY, speedX, speedY, hp);
        this.maxHp = 1000; //设置英雄机血量最大值为1000
        this.shootStrategy = shootStrategy;
    }

    public void setShootStrategy(ShootStrategy shootStrategy){
        this.shootStrategy = shootStrategy;
    }

    @Override
    public List<BaseBullet> shoot()  {
        return shootStrategy.shoot(locationX, locationY, shootNum, direction, power);
    }

    /**
     * 利用双重检查锁定，来构造单例，并返回
     * @return 单例
     */
    public static HeroAircraft getHeroAircraft(int locationX, int locationY, int speedX, int speedY, int hp, ShootStrategy shootStrategy) {
        if (heroAircraft == null) {
            synchronized (HeroAircraft.class) {
                if(heroAircraft == null) {
                    heroAircraft = new HeroAircraft(locationX, locationY, speedX, speedY, hp, shootStrategy);
                }

            }
        }
        return heroAircraft;
    }

    /**
     * 飞机前进方法
     */
    @Override
    public void forward() {
        // 英雄机由鼠标控制，不通过forward函数移动
    }

    /**
     * 给heroAircraft加血
     * @param increase 加血道具增加的血量
     */
    public void increaseHp(int increase) {
        // 设置当前Hp不超过设定的maxHp
        hp = Math.min(hp + increase, maxHp);
    }

    public void increaseShootNum(int increase) {
        shootNum += increase;
    }


    /**
     * 返回heroAircraft最大生命值
     * @return maxHp
     */
    public int getMaxHp() {
        return this.maxHp;
    }

    /**
     * 返回heroAircraft当前shootNum
     * @return shootNum
     */
    public int getShootNum() {return this.shootNum;}

}
