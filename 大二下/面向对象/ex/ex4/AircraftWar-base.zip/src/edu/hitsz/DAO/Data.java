package edu.hitsz.DAO;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author xyhstart
 * @create 2022-04-09 20:21
 */
public class Data implements Serializable {
    private String userName;
    private int score;
    private Date date;

    public Data(String userName, int score, Date date) {
        this.userName = userName;
        this.score = score;
        this.date = date;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setDate(Date date) {
        this.date = date;
    }


    public String getUserName() {
        return userName;
    }

    public int getScore() {
        return score;
    }

    public Date getDate() {
        return date;
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date2str = dateFormat.format(date);
        return this.userName + ", score: " + this.score + ", Date: " + date2str;
    }
}
