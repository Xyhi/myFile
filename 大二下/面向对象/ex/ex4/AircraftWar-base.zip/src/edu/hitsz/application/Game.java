package edu.hitsz.application;

import edu.hitsz.DAO.Data;
import edu.hitsz.DAO.DataDAOImpl;
import edu.hitsz.aircraft.*;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.basic.AbstractFlyingObject;
import edu.hitsz.factory.*;
import edu.hitsz.prop.AbstractProp;
import edu.hitsz.prop.PropBlood;
import edu.hitsz.prop.PropBullet;
import edu.hitsz.strategy.EnemyDirectShoot;
import edu.hitsz.strategy.HeroDirectShoot;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;

/**
 * 游戏主面板，游戏启动
 *
 * @author hitsz
 */
public class Game extends JPanel {

    private int backGroundTop = 0;

    /**
     * Scheduled 线程池，用于任务调度
     */
    private final ScheduledExecutorService executorService;

    /**
     * 时间间隔(ms)，控制刷新频率
     */
    private int timeInterval = 40;


    private BaseEnemyFactory baseEnemyFactory;
    private final HeroAircraft heroAircraft;
    private final List<AbstractAircraft> bossAircrafts;
    private final List<AbstractAircraft> enemyAircrafts;
    private final List<BaseBullet> heroBullets;
    private final List<BaseBullet> enemyBullets;
    private final List<AbstractProp> propList;

    private int enemyMaxNumber = 5;

    private DataDAOImpl dataDAO = null;
    private boolean gameOverFlag = false;
    private boolean bossFlag = false;
    private int bossScoreThreshold = 200;
    private int score = 0;
    private int time = 0;

    /**
     * 周期（ms)
     * 指示子弹的发射、敌机的产生频率
     */
    private int cycleDuration = 500;
    private int cycleTime = 0;


    public Game() {
        heroAircraft = HeroAircraft.getHeroAircraft();

        enemyAircrafts = new LinkedList<>();
        heroBullets = new LinkedList<>();
        enemyBullets = new LinkedList<>();
        propList = new LinkedList<>();
        bossAircrafts = new LinkedList<>();
        dataDAO = new DataDAOImpl();

        ThreadFactory gameThread = new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("game thread");
                return t;
            }
        };

        //Scheduled 线程池，用于定时任务调度
        executorService = new ScheduledThreadPoolExecutor(1, gameThread);

        //启动英雄机鼠标监听
        new HeroController(this, heroAircraft);

    }

    /**
     * 游戏启动入口，执行游戏逻辑
     */
    public void action() {

        // 定时任务：绘制、对象产生、碰撞判定、击毁及结束判定
        Runnable task = () -> {

            time += timeInterval;

            // 周期性执行（控制频率）
            if (timeCountAndNewCycleJudge()) {
                System.out.println(time);
                // 新敌机产生
                if (enemyAircrafts.size() < enemyMaxNumber) {
                    int randomNumber = (int) (Math.random() * 2 );
                    if(randomNumber == 0) {
                        baseEnemyFactory = new MobEnemyFactory();
                        enemyAircrafts.add(baseEnemyFactory.createEnemy());
                    }else {
                        baseEnemyFactory = new EliteEnemyFactory();
                        enemyAircrafts.add(baseEnemyFactory.createEnemy());
                    }
                }
                // 飞机射出子弹
                shootAction();
            }

            // 当score超过阈值时，且此时没有Boss机时，产生Boss
            if(score > 0 && score % bossScoreThreshold == 0 && !bossFlag) {
                System.out.println("Boss Activate! The score is " + score);
                baseEnemyFactory = new BossEnemyFactory();
                bossAircrafts.add(baseEnemyFactory.createEnemy());
                bossFlag = !bossFlag;
            }

            // 子弹移动
            bulletsMoveAction();

            // 飞机移动
            aircraftsMoveAction();

            // 道具移动
            propsMoveAction();

            // 撞击检测
            crashCheckAction();

            // 后处理
            postProcessAction();

            //每个时刻重绘界面
            repaint();

            // 游戏结束检查
            if (heroAircraft.getHp() <= 0) {
                // 游戏结束
                executorService.shutdown();
                gameOverFlag = true;
                // 创建游戏结束时的data信息，存入到指定文件目录下
                Data data = new Data("testUserName", score, new Date());
                try {
                    dataDAO.addData(data);
                    dataDAO.dispAllData();
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }
                System.out.println("Game Over!");
            }
        };

        /**
         * 以固定延迟时间进行执行
         * 本次任务执行完成后，需要延迟设定的延迟时间，才会执行新的任务
         */
        executorService.scheduleWithFixedDelay(task, timeInterval, timeInterval, TimeUnit.MILLISECONDS);

    }

    //***********************
    //      Action 各部分
    //***********************

    private boolean timeCountAndNewCycleJudge() {
        cycleTime += timeInterval;
        if (cycleTime >= cycleDuration && cycleTime - timeInterval < cycleTime) {
            // 跨越到新的周期
            cycleTime %= cycleDuration;
            return true;
        } else {
            return false;
        }
    }

    private void shootAction() {
        // TODO 敌机射击
        for(AbstractAircraft enemyAircraft: enemyAircrafts){
            if(enemyAircraft instanceof EliteEnemy) {
                enemyBullets.addAll(enemyAircraft.shoot());
            }
        }
        // Boss机射击
        for(AbstractAircraft bossAircraft: bossAircrafts){
            enemyBullets.addAll(bossAircraft.shoot());
        }
        // 英雄射击
        heroBullets.addAll(heroAircraft.shoot());

    }

    private void bulletsMoveAction() {
        for (BaseBullet bullet : heroBullets) {
            bullet.forward();
        }
        for (BaseBullet bullet : enemyBullets) {
            bullet.forward();
        }
    }

    private void aircraftsMoveAction() {
        for (AbstractAircraft enemyAircraft : enemyAircrafts) {
            enemyAircraft.forward();
        }
        for (AbstractAircraft bossAircraft: bossAircrafts) {
            bossAircraft.forward();
        }
    }

    private void propsMoveAction() {
        for (AbstractProp abstractProp : propList) {
            abstractProp.forward();
        }
    }

    /**
     * 碰撞检测：
     * 1. 敌机攻击英雄
     * 2. 英雄攻击/撞击敌机
     * 3. 英雄获得补给
     */
    private void crashCheckAction() {

        // TODO 敌机子弹攻击英雄
        for (BaseBullet bullet : enemyBullets) {
            if(heroAircraft.crash(bullet)) {
                heroAircraft.decreaseHp(bullet.getPower());
                bullet.vanish();
            }
        }

        // 英雄子弹攻击敌机
        for (BaseBullet bullet : heroBullets) {
            if (bullet.notValid()) {
                continue;
            }
            // 攻击普通敌机与精英机
            for (AbstractAircraft enemyAircraft : enemyAircrafts) {
                if (enemyAircraft.notValid()) {
                    // 已被其他子弹击毁的敌机，不再检测
                    // 避免多个子弹重复击毁同一敌机的判定
                    continue;
                }
                if (enemyAircraft.crash(bullet)) {
                    // 敌机撞击到英雄机子弹
                    // 敌机损失一定生命值
                    enemyAircraft.decreaseHp(bullet.getPower());
                    bullet.vanish();
                    if (enemyAircraft.notValid()) {
                        // TODO 获得分数，产生道具补给
                        if(enemyAircraft instanceof EliteEnemy) {
                            AbstractProp prop = ((EliteEnemy)enemyAircraft).createProp();
                            if(prop != null) {
                                propList.add(prop);
                            }
                        }
                        score += 10;
                    }
                }
                // 英雄机 与 敌机 相撞，均损毁
                if (enemyAircraft.crash(heroAircraft) || heroAircraft.crash(enemyAircraft)) {
                    enemyAircraft.vanish();
                    heroAircraft.decreaseHp(Integer.MAX_VALUE);
                }
            }
            for(AbstractAircraft bossEnemy: bossAircrafts) {
                // 当英雄机子弹射到Boss上时，Boss机减血
                // 这里会出现一个非常有趣的现象就是两枚子弹同时击中Boss使其血量减少到0以下
                // 从而导致bossFlag被重新取反两次从而导致后续boss无法产生的情况
                if (bossEnemy.crash(bullet)) {
                    bossEnemy.decreaseHp(bullet.getPower());
                    bullet.vanish();
                    if (bossEnemy.notValid() && bossFlag) {
                        System.out.println("Boss has been defeated");
                        bossFlag = !bossFlag; // Boss机被消灭，bossFlag设置为false
                        score += 50;
                    }
                }

                // 当英雄机与Boss机相撞时
                if (bossEnemy.crash(heroAircraft) || heroAircraft.crash(bossEnemy)) {
                    bossEnemy.vanish();
                    heroAircraft.decreaseHp(Integer.MAX_VALUE);
                }
            }
        }

        // Todo: 我方获得道具，道具生效
        for(AbstractProp prop : propList) {
            // 遍历PropList进行道具功能生效
            if (prop.crash(heroAircraft)) {
                if (prop instanceof PropBlood) {
                    prop.function(heroAircraft);
                } else if (prop instanceof PropBullet) {
                    prop.function(heroAircraft);
                } else {
                    prop.function(null);
                }
            }
        }

    }

    /**
     * 后处理：
     * 1. 删除无效的子弹
     * 2. 删除无效的敌机
     * 3. 检查英雄机生存
     * 4. 删除无效的道具
     * <p>
     * 无效的原因可能是撞击或者飞出边界
     */
    private void postProcessAction() {
        enemyBullets.removeIf(AbstractFlyingObject::notValid);
        heroBullets.removeIf(AbstractFlyingObject::notValid);
        enemyAircrafts.removeIf(AbstractFlyingObject::notValid);
        propList.removeIf(AbstractFlyingObject::notValid);
        bossAircrafts.removeIf(AbstractFlyingObject::notValid);
    }


    //***********************
    //      Paint 各部分
    //***********************

    /**
     * 重写paint方法
     * 通过重复调用paint方法，实现游戏动画
     *
     * @param  g
     */
    @Override
    public void paint(Graphics g) {
        super.paint(g);

        // 绘制背景,图片滚动
        g.drawImage(ImageManager.BACKGROUND_IMAGE, 0, this.backGroundTop - Main.WINDOW_HEIGHT, null);
        g.drawImage(ImageManager.BACKGROUND_IMAGE, 0, this.backGroundTop, null);
        this.backGroundTop += 1;
        if (this.backGroundTop == Main.WINDOW_HEIGHT) {
            this.backGroundTop = 0;
        }

        // 先绘制子弹，后绘制飞机
        // 这样子弹显示在飞机的下层
        paintImageWithPositionRevised(g, enemyBullets);
        paintImageWithPositionRevised(g, heroBullets);
        // 绘制道具
        paintImageWithPositionRevised(g, propList);
        paintImageWithPositionRevised(g, enemyAircrafts);
        // 绘制Boss机
        paintImageWithPositionRevised(g, bossAircrafts);
        // 绘制英雄机
        g.drawImage(ImageManager.HERO_IMAGE, heroAircraft.getLocationX() - ImageManager.HERO_IMAGE.getWidth() / 2,
                heroAircraft.getLocationY() - ImageManager.HERO_IMAGE.getHeight() / 2, null);

        //绘制得分和生命值
        paintScoreAndLife(g);

    }

    private void paintImageWithPositionRevised(Graphics g, List<? extends AbstractFlyingObject> objects) {
        if (objects.size() == 0) {
            return;
        }

        for (AbstractFlyingObject object : objects) {
            BufferedImage image = object.getImage();
            assert image != null : objects.getClass().getName() + " has no image! ";
            g.drawImage(image, object.getLocationX() - image.getWidth() / 2,
                    object.getLocationY() - image.getHeight() / 2, null);
        }
    }

    private void paintScoreAndLife(Graphics g) {
        int x = 10;
        int y = 25;
        g.setColor(new Color(16711680));
        g.setFont(new Font("SansSerif", Font.BOLD, 22));
        g.drawString("SCORE:" + this.score, x, y);
        y = y + 20;
        g.drawString("LIFE:" + this.heroAircraft.getHp(), x, y);
    }
}
