package edu.hitsz.factory;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.BossEnemy;
import edu.hitsz.application.ImageManager;
import edu.hitsz.application.Main;
import edu.hitsz.strategy.EnemyScatterShoot;

/**
 * @author xyhstart
 * @create 2022-03-22 21:25
 */
public class BossEnemyFactory extends BaseEnemyFactory {
    int locationX = (int) (Math.random() * (Main.WINDOW_WIDTH - ImageManager.BOSS_ENEMY_IMAGE.getWidth())) * 1;
    int locationY = (int) (Math.random() * Main.WINDOW_HEIGHT * 0.2) * 1;
    int speedX = 4;
    int speedY = 0;
    int hp = 30000;

    /**
     * BossEnemyFactory子类调用createEnemy实例方法
     * @return BossEnemy实例
     */
    @Override
    public AbstractAircraft createEnemy() {
        return new BossEnemy(locationX, locationY, speedX, speedY, hp, new EnemyScatterShoot());
    }
}
