package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;

import java.util.LinkedList;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-04-09 17:22
 */
public class EnemyScatterShoot implements ShootStrategy{

    @Override
    public List<BaseBullet> shoot(int locationX, int locationY, int shootNum, int direction, int power) {
        List<BaseBullet> res = new LinkedList<>();
        int x = locationX;
        int y = locationY + direction*2;
        int speedX = 1;
        int speedY = direction*5;
        BaseBullet baseBullet;
        for (int i = 0; i < shootNum; i++) {
            // 子弹发射位置相对飞机位置向前偏移
            // 多个子弹横向分散
            int factor = i * 2 - shootNum + 1;
            baseBullet = new EnemyBullet(x + factor * 10, y, speedX * factor, speedY, power);
            res.add(baseBullet);
        }
        return res;
    }
}
