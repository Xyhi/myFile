package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.HeroBullet;

import java.util.LinkedList;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-04-08 21:25
 */
public class HeroScatterShoot implements ShootStrategy{
    @Override
    public List<BaseBullet> shoot(int locationX, int locationY, int shootNum, int direction, int power) {
        List<BaseBullet> res = new LinkedList<>();
        int x = locationX;
        int y = locationY + direction*2;
        int speedX = 0;
        int speedY = direction*5;
        BaseBullet baseBullet;
        for (int i = 0; i < shootNum; i++) {
            // 子弹发射位置相对飞机位置向前偏移
            // 多个子弹横向分散
            int factor = (i * 2 - shootNum + 1);
            baseBullet = new HeroBullet(x + factor * 10, y, factor, speedY, power);
            res.add(baseBullet);
        }
        return  res;
    }
}
