package edu.hitsz.prop;
import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.application.Main;
import edu.hitsz.basic.AbstractFlyingObject;


/**
 * @author xyhstart
 * @create 2022-03-15 9:02
 */
abstract public class AbstractProp extends AbstractFlyingObject {
    // 考虑道具不需要移动,所以构造器中只需要x坐标以及y坐标
    public AbstractProp(int locationX, int locationY, int speedY) {
        this.locationX = locationX;
        this.locationY = locationY;
        this.speedY = speedY;
    }

    @Override
    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= Main.WINDOW_HEIGHT ) {
            vanish();
        }
    }

    // 使用可变形参接收各种飞机，将方法进行抽象
    abstract public void function(AbstractAircraft... abstractAircrafts);
}
