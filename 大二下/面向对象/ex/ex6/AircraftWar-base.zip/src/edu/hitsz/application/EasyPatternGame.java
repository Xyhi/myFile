package edu.hitsz.application;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.EliteEnemy;
import edu.hitsz.factory.EliteEnemyFactory;
import edu.hitsz.factory.MobEnemyFactory;

public class EasyPatternGame extends BaseGame{

    public EasyPatternGame() {
        super();
        //设置简单模式同一时刻出现的敌机数量的最大值
        enemyMaxNumber = 5;
        cycleDuration = 400;
        cycleTime = 0;
        //简单模式精英机产生的概率为0.20
        rate = 0.20;
    }

    /**
     * 简单模式难度不随时间提升
     */
    @Override
    protected void difImproveAction() {
    }

    /**
     * 简单模式不产生Boss机
     */
    @Override
    protected void bossCreatAction() {
    }

    @Override
    protected boolean heroBulletControl() {
        return timeCountAndNewCycleJudge();
    }

    @Override
    protected void timeReset() {
        cycleTime %= cycleDuration;
    }

    @Override
    protected boolean timeCountAndNewCycleJudge() {
        return cycleTime >= cycleDuration && cycleTime - timeInterval < cycleTime;
    }
}
