package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;
import java.lang.reflect.Constructor;
import java.util.LinkedList;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-04-18 10:49
 */
public class DirectShootStrategy implements ShootStrategy{
    @Override
    public List<BaseBullet> shoot(Class<? extends BaseBullet> bulletClass, int locationX, int locationY, int shootNum, int direction, int aircraftSpeedY, int power) {
        List<BaseBullet> res = new LinkedList<>();
        int x = locationX;
        int y = locationY + direction*2;
        int speedX = 0;
        int speedY = aircraftSpeedY + direction*5;
        BaseBullet baseBullet = null;
        try {
            Constructor<? extends BaseBullet> constructor = bulletClass.getDeclaredConstructor(int.class, int.class, int.class, int.class, int.class);
            baseBullet = constructor.newInstance(x, y, speedX, speedY, power);
        } catch (Exception e) {
            e.printStackTrace();
        }
        res.add(baseBullet);
        return res;
    }
}
