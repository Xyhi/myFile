package edu.hitsz.Observer;

/**
 * @author xyhstart
 * @create 2022-04-29 9:46
 */
public interface Observer {
    void update();
}
