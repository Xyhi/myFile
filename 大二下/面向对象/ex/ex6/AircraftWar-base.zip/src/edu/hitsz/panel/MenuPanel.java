package edu.hitsz.panel;

import edu.hitsz.application.BaseGame;
import edu.hitsz.application.ImageManager;
import edu.hitsz.application.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Arrays;

/**
 * @author xyhstart
 * @create 2022-04-22 9:05
 */
public class MenuPanel extends Container {

    private JPanel MainPanel;
    private JPanel topPane;
    private JButton easyModeButton;
    private JButton normModeButton;
    private JButton hardModeButton;
    private JPanel bottomPane;
    private JComboBox audioBox;
    private JLabel audioControlLabel;
    public static boolean audioFlag = true;

    public MenuPanel(){
        easyModeButton.setPreferredSize(new Dimension(200, 100));
        easyModeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BaseGame.difficulty = 1;
                ImageManager.setBackgroundImage("src/images/bg.jpg");
                synchronized (Main.class) {
                    (Main.class).notify();
                }

            }
        });
        normModeButton.setPreferredSize(new Dimension(200, 100));
        normModeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BaseGame.difficulty = 2;
                ImageManager.setBackgroundImage("src/images/bg2.jpg");
                synchronized (Main.class) {
                    (Main.class).notify();
                }
            }
        });
        hardModeButton.setPreferredSize(new Dimension(200, 100));
        hardModeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                BaseGame.difficulty = 3;
                ImageManager.setBackgroundImage("src/images/bg3.jpg");
                synchronized (Main.class) {
                    (Main.class).notify();
                }
            }
        });
        audioBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange() == ItemEvent.SELECTED) {
                    //音效选择开关
                    audioFlag = !Arrays.toString(e.getItemSelectable().getSelectedObjects()).equals("[关]");
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("MenuPanel");
        frame.setPreferredSize(new Dimension(1000,1000));
        frame.setContentPane(new MenuPanel().MainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getMainPanel() {
        return MainPanel;
    }
}
