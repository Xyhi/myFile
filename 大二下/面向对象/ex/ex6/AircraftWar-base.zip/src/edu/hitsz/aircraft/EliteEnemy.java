package edu.hitsz.aircraft;

import edu.hitsz.application.Main;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;
import edu.hitsz.factory.PropBloodFactory;
import edu.hitsz.factory.PropBombFactory;
import edu.hitsz.factory.PropBulletFactory;
import edu.hitsz.factory.BasePropFactory;
import edu.hitsz.prop.AbstractProp;
import edu.hitsz.strategy.ShootStrategy;

import java.util.List;
import java.util.Random;

/**
 * @author xyhstart
 * @create 2022-03-14 21:44
 */
public class EliteEnemy extends AbstractAircraft {

    private static int power = 20;          // 子弹伤害
    private int direction = 1;       // 子弹射击方向 (向上发射：1，向下发射：-1)
    private int shootNum = 1;        // 精英机每次发射的子弹数目
    private BasePropFactory basePropFactory; // 道具工厂，掉落时创建道具

    public EliteEnemy(int locationX, int locationY, int speedX, int speedY, int hp, ShootStrategy shootStrategy) {
        super(locationX, locationY, speedX, speedY, hp, shootStrategy);
    }

    @Override
    public void forward() {
        super.forward();
        // 判定 y 轴向下飞行出界
        if (locationY >= Main.WINDOW_HEIGHT ) {
            vanish();
        }
    }

    public void setShootStrategy(ShootStrategy shootStrategy){
        this.shootStrategy = shootStrategy;
    }

    /**
     * 精英机发射子弹功能
     * @return 精英机的子弹
     */
    @Override
    public List<BaseBullet> shoot() {
        return shootStrategy.shoot(EnemyBullet.class, locationX, locationY, shootNum,direction, speedY, power);
    }

    /**
     * 精英机以一定概率产生道具
     * @return 精英机产生的道具
     */
    public AbstractProp createProp() {
        // 随机数产生器
        Random r = new Random();
        double randomNumber = r.nextDouble();
        // 设定产生道具产生的频率
        if(randomNumber < 0.9) {
            int propRandom = r.nextInt(3);
            switch (propRandom) {
                // 加血道具
                case 0:
                    basePropFactory = new PropBloodFactory();
                    return basePropFactory.createProp(this.getLocationX(), this.getLocationY(), 5);
                // 火力道具
                case 1:
                    basePropFactory = new PropBulletFactory();
                    return basePropFactory.createProp(this.getLocationX(), this.getLocationY(), 5);
                // 炸弹道具
                case 2:
                    basePropFactory = new PropBombFactory();
                    return basePropFactory.createProp(this.getLocationX(), this.getLocationY(), 5);
                default:
                    return null;
            }
        }
        return null;
    }

    public static void improveBullet(double factor) {
        power += factor * 20;
    }

}
