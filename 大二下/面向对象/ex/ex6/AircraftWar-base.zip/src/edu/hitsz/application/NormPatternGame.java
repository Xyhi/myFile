package edu.hitsz.application;

import edu.hitsz.aircraft.BossEnemy;
import edu.hitsz.aircraft.EliteEnemy;
import edu.hitsz.factory.BossEnemyFactory;
import edu.hitsz.factory.EliteEnemyFactory;
import edu.hitsz.factory.MobEnemyFactory;

public class NormPatternGame extends BaseGame{

    //属性提升倍数
    protected double factor = 0.02;
    //正常模式初始难度时间
    protected int diffTime = 0;
    //正常模式每次提升难度的频率
    protected int diffDuration = 2000;

    /**
     * 指示飞机子弹的发射频率
     */
    protected int heroCycleTime = 0;
    protected int heroCycleTimeDuration = 600;
    /**
     * 指示正常模式下敌机属性提升最大值
     */
    protected double maxFactor = 0.3;
    /**
     * 周期（ms)
     * 指示子弹的发射、敌机的产生频率
     */

    public NormPatternGame() {
        super();
        //设置正常模式同一时刻出现的敌机数量的最大值
        enemyMaxNumber = 8;
        //正常模式产生精英机初始概率为0.2
        rate = 0.2;
        //正常模式指示子弹的发射、敌机的初始产生频率
        cycleDuration = 600;
        cycleTime = 0;
    }

    @Override
    protected void difImproveAction() {
        if(diffImprove()) {
            //设置属性最多提升到1.4倍
            if(factor < maxFactor) {
                factor += 0.02;
                cycleDuration -= 15;
                heroCycleTimeDuration -= 5;
                rate += 0.01;
                enemyImprove();
                System.out.printf("提高难度!精英敌机概率：%.2f,敌机周期：%.2f, 敌机属性提升倍率：%.2f, 子弹属性提升倍率：%.2f\n", rate, (double) cycleDuration / timeInterval, 1 + factor, 1 + factor);
                System.out.printf("英雄机子弹频率加快,周期为%.2f\n", (double) heroCycleTimeDuration / timeInterval);
            }else {
                System.out.printf("难度已经提升到最大, 精英敌机概率：%.2f,敌机周期：%.2f, 敌机属性提升倍率：%.2f, 子弹属性提升倍率：%.2f\n", rate, (double) cycleDuration / timeInterval, 1 + factor, 1 + factor);
            }
        }
    }

    /**
     * 正常模式每次产生Boss机血量不变
     */
    @Override
    protected void bossCreatAction() {
        // 当score超过阈值时，且此时没有Boss机时，产生Boss
        if(score > 0 && score % bossScoreThreshold == 0 && !bossFlag) {
            System.out.println("Boss Activate! The score is " + score);
            baseEnemyFactory = new BossEnemyFactory();
            bossAircrafts.add(baseEnemyFactory.createEnemy());
            bossFlag = !bossFlag;
            if(musicList[6] == null || !musicList[6].isAlive()) {
                MusicThread bossBGM = new MusicThread("src/videos/bgm_boss.wav");
                musicList[6] = bossBGM;
                musicList[6].start();
            }
        }
    }

    /**
     * 正常模式控制1/2初始概率产生精英敌机
     */
    //提升MobEnemy以及EliteEnemy的属性，同时提高子弹速度和伤害
    protected void enemyImprove() {
        EliteEnemyFactory.improveEnemy(factor);
        MobEnemyFactory.improveEnemy(factor);
        EliteEnemy.improveBullet(factor);
        BossEnemy.improveBullet(factor);
    }

    //随时间推移，提升难度
    protected boolean diffImprove() {
        diffTime += timeInterval;

        if (diffTime >= diffDuration && diffTime - timeInterval < diffTime) {
            // 跨越到新的周期
            diffTime %= diffDuration;
            return true;
        } else {
            return false;
        }
    }
    @Override

    //控制英雄机子弹发射频率
    protected boolean heroBulletControl() {
        heroCycleTime += timeInterval;
        if (heroCycleTime >= heroCycleTimeDuration &&  heroCycleTime - timeInterval < heroCycleTime) {
            // 跨越到新的周期
            heroCycleTime %= heroCycleTimeDuration;
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void timeReset() {
        // 跨越到新的周期
        cycleTime %= cycleDuration;
    }

    @Override
    protected boolean timeCountAndNewCycleJudge() {
        return cycleTime >= cycleDuration && cycleTime - timeInterval < cycleTime;
    }

}
