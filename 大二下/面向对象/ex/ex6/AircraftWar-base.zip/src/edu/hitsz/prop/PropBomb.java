package edu.hitsz.prop;

import edu.hitsz.Observer.Observer;
import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.bullet.BaseBullet;

import java.util.ArrayList;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-03-15 8:54
 */
public class PropBomb extends AbstractProp{
    //观察者列表
    private List<Observer> enemyList = null;

    public PropBomb(int locationX, int locationY, int speedY) {
        super(locationX, locationY, speedY);
        enemyList = new ArrayList<>();
    }

    //增加观察者
    public void addEnemyObs(Observer observer) {
        enemyList.add(observer);
    }

    //移除观察者
    public void removeObs(Observer observer) {
        enemyList.remove(observer);
    }

    //通知所有观察者
    public void notifyAllEnemy() {
        for(Observer observer: enemyList) {
            observer.update();
        }
    }

    /**
     * 炸弹道具，销毁页面中所有敌机，并返回得分
     * @param abstractAircraft
     */
    @Override
    public void function(AbstractAircraft abstractAircraft) {
        notifyAllEnemy();
        vanish();
    }

}
