package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;

import java.lang.reflect.Constructor;
import java.util.LinkedList;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-04-18 10:49
 */
public class ScatterShootStrategy implements ShootStrategy{

    @Override
    public List<BaseBullet> shoot(Class<? extends BaseBullet> bulletClass, int locationX, int locationY, int shootNum, int direction, int aircraftSpeedY, int power) {
        List<BaseBullet> res = new LinkedList<>();
        int x = locationX;
        int y = locationY + direction*2;
        int speedX = 0;
        int speedY = aircraftSpeedY + direction*5;
        BaseBullet baseBullet = null;
        Constructor<? extends BaseBullet> constructor;
        for (int i = 0; i < shootNum; i++) {
            try {
                constructor = bulletClass.getDeclaredConstructor(int.class, int.class, int.class, int.class, int.class);
                // 子弹发射位置相对飞机位置向前偏移
                // 多个子弹横向分散
                int factor = (i * 2 - shootNum + 1);
                baseBullet = constructor.newInstance(x + factor * 10, y, factor, speedY, power);
            } catch (Exception e) {
                e.printStackTrace();
            }
            res.add(baseBullet);
        }
        return  res;
    }
}
