package edu.hitsz.application;

import edu.hitsz.aircraft.BossEnemy;
import edu.hitsz.factory.BossEnemyFactory;
import edu.hitsz.factory.EliteEnemyFactory;
import edu.hitsz.factory.MobEnemyFactory;

public class HardPatternGame extends NormPatternGame{
    //定义Boss机产生次数
    private int bossNum = 0;
    //定义Boss每次加血的量
    private int bossIncreaseHp = 100;

    public HardPatternGame() {
        super();
        //设置困难模式同一时刻出现的敌机数量的最大值
        enemyMaxNumber = 10;
        //困难模式产生精英机初始概率为0.3
        rate = 0.3;
        //困难模式指示子弹的发射、敌机的初始产生频率
        cycleDuration = 600;
        //困难模式下难度提升周期为1500
        diffDuration = 2000;
        //困难模式下英雄机子弹属性提升周期为500
        heroCycleTimeDuration = 500;
        //困难模式下敌机属性提升最大倍数
        maxFactor = 0.4;
    }

    @Override
    protected void difImproveAction() {
        if(diffImprove()) {
            //设置属性最多提升到1.4倍
            if(factor < maxFactor) {
                factor += 0.02;
                //困难模式下指示敌机、子弹产生周期-20
                cycleDuration -= 20;
                //困难模式下英雄机子弹速率提升周期减少
                heroCycleTimeDuration -= 10;
                //困难模式下精英敌机产生倍率每次加0.02
                rate += 0.02;
                enemyImprove();
                System.out.printf("提高难度!精英敌机概率：%.2f,敌机周期：%.2f, 敌机属性提升倍率：%.2f, 子弹属性提升倍率：%.2f\n", rate, (double) cycleDuration / timeInterval, 1 + factor, 1 + factor);
                System.out.printf("英雄机子弹频率加快,周期为%.2f\n", (double) heroCycleTimeDuration / timeInterval);
            }else {
                System.out.printf("难度已经提升到最大, 精英敌机概率：%.2f,敌机周期：%.2f, 敌机属性提升倍率：%.2f, 子弹属性提升倍率：%.2f\n", rate, (double) cycleDuration / timeInterval, 1 + factor, 1 + factor);
            }
        }
    }

    /**
     * 困难模式每次召唤Boss机提升boss机血量
     */
    @Override
    protected void bossCreatAction() {
        // 当score超过阈值时，且此时没有Boss机时，产生Boss
        if(score > 0 && score % bossScoreThreshold == 0 && !bossFlag) {
            bossNum++;
            System.out.println("Boss Activate! The score is " + score);
            baseEnemyFactory = new BossEnemyFactory();
            bossAircrafts.add(baseEnemyFactory.createEnemy());
            //提升Boss血量
            ((BossEnemy) bossAircrafts.get(0)).increaseHp((bossNum - 1) * bossIncreaseHp);
            System.out.printf("Boss Hp提升倍率为%.2f\n" ,(double)bossAircrafts.get(0).getHp()/600);
            bossFlag = !bossFlag;
            if(musicList[6] == null || !musicList[6].isAlive()) {
                MusicThread bossBGM = new MusicThread("src/videos/bgm_boss.wav");
                musicList[6] = bossBGM;
                musicList[6].start();
            }
        }
    }

}
