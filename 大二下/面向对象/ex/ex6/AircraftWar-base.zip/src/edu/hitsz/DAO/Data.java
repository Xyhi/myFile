package edu.hitsz.DAO;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author xyhstart
 * @create 2022-04-09 20:21
 */
public class Data implements Serializable {
    private long id;
    private String userName;
    private int score;
    private Date date;

    public Data(long id, String userName, int score, Date date) {
        this.id = id;
        this.userName = userName;
        this.score = score;
        this.date = date;
    }

    public long getId() {return id;}

    public int getScore() {
        return score;
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date2str = dateFormat.format(date);
        return this.userName + ", score: " + this.score + ", Date: " + date2str;
    }

    public String[] getDataStr(){
        String[] list = new String[3];
        list[0] = userName;
        list[1] = Integer.toString(score);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date2str = dateFormat.format(date);
        list[2] = date2str;
        return  list;
    }
}
