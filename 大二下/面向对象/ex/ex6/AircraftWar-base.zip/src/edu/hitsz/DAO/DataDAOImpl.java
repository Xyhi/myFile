package edu.hitsz.DAO;

import edu.hitsz.application.BaseGame;

import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-04-09 21:01
 */
public class DataDAOImpl implements DataDAO{
    // 根据指定路径创建file文件
    File file1 = Paths.get("src\\GameData1.data").toFile();
    File file2 = Paths.get("src\\GameData2.data").toFile();
    File file3 = Paths.get("src\\GameData3.data").toFile();
    File file;
    {
        switch (BaseGame.difficulty) {
            case 1: file = file1;break;
            case 2: file = file2;break;
            case 3: file = file3;break;
            default:
        }
    }

    /**
     * 获取得分列表中的所有信息
     * @return 得分列表
     * @throws IOException
     * @throws ClassNotFoundException
     */
    @Override
    public List<Data> getAllData() throws IOException, ClassNotFoundException {
        if(file.exists() && file.length() != 0) {
            List<Data> dataList = new ArrayList<>();
            FileInputStream fis = null;
            ObjectInputStream ois = null;
            fis = new FileInputStream(file);
            ois = new ObjectInputStream(fis);
            // 反序列化读取数据到列表中
            while (fis.available() > 0) {
                dataList.add((Data) ois.readObject());
            }
            return dataList;
        }else {
            return null;
        }
    }

    /**
     * 每次游戏结束后添加游戏得分数据
     * @param data 游戏得分信息，包括userName，score，date
     * @throws IOException
     * @throws ClassNotFoundException
     */
    @Override
    public void addData(Data data) throws IOException, ClassNotFoundException {
        FileOutputStream fos = new FileOutputStream(file, true);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        long pos = 0;
        // 利用file.length == Header.length判断是否为第一次写入
        if(file.exists() && file.length() != 4) {
            // 由于fileOutputStream追加文件时，会自动追加Header(length=4)导致Obj序列读取出错，所以这里将Header信息过滤
            pos = fos.getChannel().position() - 4;
            fos.getChannel().truncate(pos);
        }
        oos.writeObject(data);
        oos.close();
        fos.close();
    }

    @Override
    public void deleteData(long dataId) throws IOException, ClassNotFoundException {
        List<Data> dataList = getAllData();
        dataList.removeIf(data -> data.getId() == dataId);

        if(dataList.size() == 0){
            FileWriter writer = new FileWriter(file);
            writer.write("");
            writer.flush();
            writer.close();
        }else {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            //将删除后的list重新写入文件
            for(Data data: dataList) {
                oos.writeObject(data);
            }
            oos.close();
            fos.close();
        }
    }
}
