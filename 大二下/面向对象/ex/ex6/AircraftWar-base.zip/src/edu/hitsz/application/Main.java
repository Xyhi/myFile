package edu.hitsz.application;

import edu.hitsz.panel.BoardPanel;
import edu.hitsz.panel.MenuPanel;

import javax.swing.*;
import java.awt.*;

/**
 * 程序入口
 * @author hitsz
 */
public class Main {

    public static final int WINDOW_WIDTH = 512;
    public static final int WINDOW_HEIGHT = 768;


    public static void main(String[] args) throws InterruptedException {
        System.out.println("Hello Aircraft War");

        // 获得屏幕的分辨率，初始化 Frame
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        JFrame frame = new JFrame("Aircraft War");
        frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        frame.setResizable(false);
        //设置窗口的大小和位置,居中放置
        frame.setBounds(((int) screenSize.getWidth() - WINDOW_WIDTH) / 2, 0,
                WINDOW_WIDTH, WINDOW_HEIGHT);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MenuPanel menuPanel = new MenuPanel();
        JPanel menuMainPanel = menuPanel.getMainPanel();
        frame.setContentPane(menuMainPanel);
        frame.setVisible(true);
        System.out.println(Thread.currentThread().getName());

        synchronized (Main.class) {
            (Main.class).wait();
        }
        BaseGame game = null;
        switch (BaseGame.difficulty) {
            case 1: game = new EasyPatternGame(); break;
            case 2: game = new NormPatternGame(); break;
            case 3: game = new HardPatternGame(); break;
            default:
        }
        frame.remove(menuMainPanel);
        frame.setContentPane(game);
        frame.setVisible(true);
        game.action();

        synchronized (Main.class) {
            (Main.class).wait();
        }

        frame.remove(game);
        BoardPanel boardPanel = new BoardPanel();
        JPanel boardMainPanel = boardPanel.getMainPanel();
        frame.setContentPane(boardMainPanel);
        frame.setVisible(true);

        //主线程等待判断是否进行排行榜重绘
        synchronized (Main.class) {
            (Main.class).wait();
        }

        //传入Game中数据更新flag,判断是否填入数据,排行榜进行重绘
        if(BaseGame.dataUpdateFlag){
            boardPanel = new BoardPanel();
            boardMainPanel = boardPanel.getMainPanel();
            frame.setContentPane(boardMainPanel);
            frame.setVisible(true);
        }
    }
}
