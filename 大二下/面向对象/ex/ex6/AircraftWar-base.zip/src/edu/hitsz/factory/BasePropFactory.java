package edu.hitsz.factory;

import edu.hitsz.prop.AbstractProp;

/**
 * @author xyhstart
 * @create 2022-03-22 21:42
 */
abstract public class BasePropFactory {

    /**
     *  工厂方法创造道具对象
     * @param locationX 道具x坐标
     * @param locationY 道具y坐标
     * @param speedY 道具速度speedY
     * @return 随机产生道具
     */
    public abstract AbstractProp createProp(int locationX, int locationY, int speedY);
}
