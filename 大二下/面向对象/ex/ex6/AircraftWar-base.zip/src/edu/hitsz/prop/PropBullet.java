package edu.hitsz.prop;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.strategy.DirectShootStrategy;
import edu.hitsz.strategy.ScatterShootStrategy;

import java.util.concurrent.TimeUnit;

/**
 * @author xyhstart
 * @create 2022-03-15 8:55
 */
public class PropBullet extends AbstractProp{
    private int maxShootNum = 3; // 设置最大子弹数目
    private static Thread propBulletThread;
    private static boolean propBulletValid = false;
    public PropBullet(int locationX, int locationY, int speedY) {
        super(locationX, locationY, speedY);
    }

    /**
     * 测试火力道具功能
     * @param abstractAircraft
     */
    @Override
    public void function(AbstractAircraft abstractAircraft) {
        //如果活力道具生效中，则终止线程，重新开启道具线程
        if(propBulletValid) {
            propBulletThread.interrupt();
        }
        HeroAircraft heroAircraft = (HeroAircraft)abstractAircraft;
        int curShootNum = heroAircraft.getShootNum();
        // 设置英雄机shoot为散射
        heroAircraft.setShootStrategy(new ScatterShootStrategy());
        // 为考虑难度系数和线程安全，火力道具直接改变弹道为散射，且发射子弹数目为3
        heroAircraft.setShootNum(maxShootNum);
        //功能实现后销毁
        vanish();
        propBulletValid = true;
        //由于定义在道具中的function的run方法无法传递heroAircraft参数，故写在Game中，后续进行优化
        Runnable r = () -> {
            try {
                //设置活力道具生效时间为10s
                TimeUnit.SECONDS.sleep(10);
                heroAircraft.setShootStrategy(new DirectShootStrategy());
                heroAircraft.setShootNum(1);
                propBulletValid = false;
            } catch (InterruptedException e) {
                System.out.println("道具更新");
            }
            //设置活力道具标志失效
        };
        propBulletThread = new Thread(r);
        propBulletThread.start();
    }
}
