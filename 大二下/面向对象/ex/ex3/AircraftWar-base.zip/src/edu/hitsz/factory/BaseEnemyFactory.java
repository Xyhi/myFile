package edu.hitsz.factory;

import edu.hitsz.aircraft.AbstractAircraft;

/**
 * 用于创造敌机的工厂
 * @author xyhstart
 * @create 2022-03-22 21:22
 */
abstract public class BaseEnemyFactory {
    public abstract AbstractAircraft createEnemy();
}
