package junitTest.demo;

import edu.hitsz.aircraft.EliteEnemy;
import edu.hitsz.application.Main;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


/**
 * @author xyhstart
 * @create 2022-03-29 15:46
 */
class EliteEnemyTest {

    private EliteEnemy eliteEnemy;
    int locationX = 0;
    int locationY = 0;
    int speedX = 5;
    int speedY = 10;
    int hp = 60;

    @BeforeEach
    void setUp() {
        eliteEnemy = new EliteEnemy(locationX, locationY, speedX, speedY, hp);
    }

    @AfterEach
    void tearDown() {
        eliteEnemy = null;
    }

    @Test
    @DisplayName("Test EliteEnemy forward method")
    void forward() {
        // 设置eliteEnemy的纵坐标超出屏幕，检测是否vanish
        eliteEnemy.setLocation(locationX, Main.WINDOW_HEIGHT);
        eliteEnemy.forward();
        assertTrue(eliteEnemy.notValid());
    }

    @Test
    @DisplayName("Test EliteEnemy shoot method")
    void shoot() {
        // 检测eliteEnemy返回子弹列表是否为空
        assertNotNull(eliteEnemy.shoot());
    }
}
