package edu.hitsz.factory;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.EliteEnemy;
import edu.hitsz.application.ImageManager;
import edu.hitsz.application.Main;

/**
 * @author xyhstart
 * @create 2022-03-22 21:25
 */
public class EliteEnemyFactory extends EnemyFactory{
    int locationX = (int) (Math.random() * (Main.WINDOW_WIDTH - ImageManager.ELITE_ENEMY_IMAGE.getWidth())) * 1;
    int locationY = (int) (Math.random() * Main.WINDOW_HEIGHT * 0.2) * 1;
    int speedX;
    int speedY = 10;
    int hp = 60;

    // 工厂方法返回EliteEnemy对象
    @Override
    public AbstractAircraft createEnemy() {
        // 设置EliteAircraft可以左右飞行或者直线飞行

        // 1/3的概率产生左右飞行的飞机
        if(System.currentTimeMillis() % 3 == 0) {
            speedX = 5;
        } else {
            speedX = 0;
        }

        // 返回产生的敌机
        return new EliteEnemy(locationX,
                locationY,
                speedX,
                speedY,
                hp // 给精英机血量弄多点，不然有辱其名);
        );
    }
}
