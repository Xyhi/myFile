package junitTest.demo;

import edu.hitsz.application.Main;
import edu.hitsz.bullet.BaseBullet;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author xyhstart
 * @create 2022-03-29 20:03
 */
class BaseBulletTest {

    private BaseBullet baseBullet;
    int locationX = 0;
    int locationY = 0;
    int speedX = 0;
    int speedY = 5;
    int power = 5;

    @BeforeEach
    void setUp() {
        baseBullet = new BaseBullet(locationX, locationY, speedX, speedY, power);
    }

    @AfterEach
    void tearDown() {
        baseBullet = null;
    }

    @Test
    @DisplayName("Test BaseBullet forward method")
    void forward() {
        // 检测x出界情况
        baseBullet.setLocation(0, locationY);
        baseBullet.forward();
        assertTrue(baseBullet.notValid());

        // 重新new BaseBullet，检测x轴右侧出界情况
        baseBullet = new BaseBullet(Main.WINDOW_WIDTH, locationY, speedX, speedY, power);
        baseBullet.forward();
        assertTrue(baseBullet.notValid());

        // 判定y向下出界情况:speedY大于0, 且locationY >= Main.WINDOW_HEIGHT
        baseBullet = new BaseBullet(5, Main.WINDOW_HEIGHT, speedX, speedY, power);
        baseBullet.forward();
        assertTrue(baseBullet.notValid());

        // 判定当speedY小于0，且locationY >= Main.WINDOW_HEIGHT,此时子弹向上飞行不属于出界
        baseBullet = new BaseBullet(5, Main.WINDOW_HEIGHT, speedX, -speedY, power);
        baseBullet.forward();
        assertFalse(baseBullet.notValid());

        // 判定y轴向上出界情况
        baseBullet = new BaseBullet(5, 0, speedX, -speedY, power);
        baseBullet.forward();
        assertTrue(baseBullet.notValid());

        // 判定当speedY大于0，且locationY <= 0,此时子弹向下飞行不属于出界
        baseBullet = new BaseBullet(5, 0, speedX, speedY, power);
        baseBullet.forward();
        assertFalse(baseBullet.notValid());
    }

    @Test
    @DisplayName("Test BaseBullet getPower method")
    void getPower() {
        // 判断BaseBullet getPower返回的值是否等于设定的子弹power
        assertEquals(baseBullet.getPower(), power);
    }
}