package edu.hitsz.prop;

import edu.hitsz.aircraft.AbstractAircraft;

/**
 * @author xyhstart
 * @create 2022-03-15 8:55
 */
public class PropBullet extends AbstractProp{

    public PropBullet(int locationX, int locationY, int speedY) {
        super(locationX, locationY, speedY);
    }

    /**
     * 测试火力道具功能
     * @param abstractAircrafts
     */
    @Override
    public void function(AbstractAircraft... abstractAircrafts) {
        if(abstractAircrafts == null) {
            System.out.println("FireSupply active!");
        }
        vanish();
    }
}
