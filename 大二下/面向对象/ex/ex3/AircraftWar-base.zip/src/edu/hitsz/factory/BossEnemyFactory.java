package edu.hitsz.factory;

import edu.hitsz.aircraft.AbstractAircraft;

/**
 * @author xyhstart
 * @create 2022-03-22 21:25
 */
public class BossEnemyFactory extends BaseEnemyFactory {

    /**
     * BossEnemyFactory子类调用createEnemy实例方法
     * @return BossEnemy实例
     */
    @Override
    public AbstractAircraft createEnemy() {
        return null;
    }
}
