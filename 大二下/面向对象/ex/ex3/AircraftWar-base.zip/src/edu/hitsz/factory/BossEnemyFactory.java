package edu.hitsz.factory;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.BossEnemy;

/**
 * @author xyhstart
 * @create 2022-03-22 21:25
 */
public class BossEnemyFactory extends EnemyFactory{

    // 工厂方法返回BossEnemy对象
    @Override
    public AbstractAircraft createEnemy() {
        return null;
    }
}
