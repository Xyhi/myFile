package junitTest.demo;

import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.HeroBullet;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author xyhstart
 * @create 2022-03-29 19:21
 */
class HeroAircraftTest {
    private HeroAircraft heroAircraft;
    int locationX = 0;
    int locationY = 0;
    int speedX = 5;
    int speedY = 10;
    int hp = 800;

    @BeforeEach
    void setUp() {
        heroAircraft = HeroAircraft.getHeroAircraft(locationX, locationY, speedX, speedY, hp);
    }

    @AfterEach
    void tearDown() {
        heroAircraft = null;
    }

    @Test
    @DisplayName("Test HeroAircraft shoot method")
    void shoot() {
        // 检测英雄机返回子弹是否为空
        System.out.println("**--- Test shoot method executed ---**");
        assertNotNull(heroAircraft.shoot());
    }

    @Test
    @DisplayName("Test HeroAircraft increaseHp method")
    void increaseHp() {
        // 检测英雄机加血功能是否正常
        int increaseHp = 100;
        System.out.println("**--- Test increaseHp method executed ---**");
        for(int i = 0; i < 5; i++) {
            // 记录加血前heroAircraft血量
            int temp = heroAircraft.getHp();
            System.out.println("Now the heroAircraft's hp is " + temp);
            heroAircraft.increaseHp(increaseHp);
            assertEquals(heroAircraft.getHp(), Math.min(temp + increaseHp, heroAircraft.getMaxHp()));
        }
    }
}