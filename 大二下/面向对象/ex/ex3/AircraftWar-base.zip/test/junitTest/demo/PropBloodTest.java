package junitTest.demo;

import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.prop.AbstractProp;
import edu.hitsz.prop.PropBlood;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author xyhstart
 * @create 2022-03-29 20:37
 */
class PropBloodTest {

    private PropBlood propBlood;
    int locationX = 10;
    int locationY = 10;
    int speedY = 5;

    @BeforeEach
    void setUp() {
        propBlood = new PropBlood(locationX, locationY, speedY);
    }

    @AfterEach
    void tearDown() {
        propBlood = null;
    }

    @Test
    @DisplayName("Test PropBlood function method")
    void function() {
        System.out.println("**--- Test function method executed ---**");
        // 传入heroAircraft实例,判断英雄机是否加血,且加血功能完成后,英雄机学量是否提升
        HeroAircraft heroAircraft = HeroAircraft.getHeroAircraft(locationX, locationY, 0, 0, 100);
        // 记录英雄机当前血量
        int temp = heroAircraft.getHp();
        // 调用propBlood.function
        propBlood.function(heroAircraft);
        // 检测英雄机血量是否提升
        assertEquals(heroAircraft.getHp(), temp + propBlood.getIncrease());
        // 检测道具调用完是否被vanish
        assertTrue(propBlood.notValid());
    }

    @Test
    @DisplayName("Test PropBlood crash method")
    void crash() {
        System.out.println("**--- Test crash method executed ---**");
        // 传入heroAircraft实例,使其与道具具有相同的横纵坐标，判断其是否与相撞
        HeroAircraft heroAircraft = HeroAircraft.getHeroAircraft(locationX, locationY, 0, 0, 60);
        // 调用propBlood.crash判断是否与heroAircraft相撞
        assertTrue(propBlood.crash(heroAircraft));
    }
}