package junitTest.demo;

import edu.hitsz.aircraft.EliteEnemy;
import edu.hitsz.application.Main;
import edu.hitsz.prop.AbstractProp;
import edu.hitsz.prop.PropBlood;
import edu.hitsz.prop.PropBomb;
import edu.hitsz.strategy.DirectShootStrategy;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


/**
 * @author xyhstart
 * @create 2022-03-29 15:46
 */
class EliteEnemyTest {

    private EliteEnemy eliteEnemy;
    int locationX = 0;
    int locationY = 0;
    int speedX = 5;
    int speedY = 10;
    int hp = 60;

    @BeforeEach
    void setUp() {
        eliteEnemy = new EliteEnemy(locationX, locationY, speedX, speedY, hp, new DirectShootStrategy());
    }

    @AfterEach
    void tearDown() {
        eliteEnemy = null;
    }

    @Test
    @DisplayName("Test EliteEnemy forward method")
    void forward() {
        System.out.println("**--- Test forward method executed ---**");
        // 设置eliteEnemy的纵坐标超出屏幕，检测是否vanish
        eliteEnemy.setLocation(locationX, Main.WINDOW_HEIGHT);
        eliteEnemy.forward();
        assertTrue(eliteEnemy.notValid());
    }

    @Test
    @DisplayName("Test EliteEnemy shoot method")
    void shoot() {
        System.out.println("**--- Test forward method executed ---**");
        // 检测eliteEnemy返回子弹列表是否为空
        assertNotNull(eliteEnemy.shoot());
    }

    @Test
    @DisplayName("Test Elite createProp method")
    void createProp() {
        // 由于createProp方法是一个随机产生道具的方法，故我们用较大的N，来模拟产生过程，判断是否所有道具都被产生
        int num = 1000;
        List<AbstractProp> propList = new LinkedList<>();
        for(int i = 0; i < num; i++) {
            propList.add(eliteEnemy.createProp());
        }
        // 设置null，propBlood, propBomb, propBullet 产生标志
        boolean nullFlag = false, bloodFlag = false, bombFlag = false, bulletFlag = false;
        for(AbstractProp prop: propList) {
            if (prop == null) {
                nullFlag = true;
            } else if(prop instanceof PropBlood) {
                bloodFlag = true;
            } else if(prop instanceof PropBomb) {
                bombFlag = true;
            } else {
                bulletFlag = true;
            }
        }
        System.out.println("**--- Test createProp method executed ---**");
        assertTrue(nullFlag && bloodFlag && bombFlag && bulletFlag);
    }
}
