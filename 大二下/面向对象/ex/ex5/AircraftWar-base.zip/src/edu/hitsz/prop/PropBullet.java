package edu.hitsz.prop;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.HeroAircraft;
import edu.hitsz.strategy.ScatterShootStrategy;

/**
 * @author xyhstart
 * @create 2022-03-15 8:55
 */
public class PropBullet extends AbstractProp{
    private int maxShootNum = 3; // 设置最大子弹数目

    public PropBullet(int locationX, int locationY, int speedY) {
        super(locationX, locationY, speedY);
    }

    /**
     * 测试火力道具功能
     * @param abstractAircrafts
     */
    @Override
    public void function(AbstractAircraft... abstractAircrafts) {
        if(abstractAircrafts[0] instanceof HeroAircraft) {
            HeroAircraft heroAircraft = (HeroAircraft)abstractAircrafts[0];
            int curShootNum = heroAircraft.getShootNum();
            // 设置英雄机shoot为散射
            heroAircraft.setShootStrategy(new ScatterShootStrategy());
            // 为考虑难度系数和线程安全，火力道具直接改变弹道为散射，且发射子弹数目为3
            heroAircraft.setShootNum(maxShootNum);
        }
        //功能实现后销毁
        vanish();
    }
}
