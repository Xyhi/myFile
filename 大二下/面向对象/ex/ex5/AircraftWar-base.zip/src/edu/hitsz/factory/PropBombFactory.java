package edu.hitsz.factory;

import edu.hitsz.prop.AbstractProp;
import edu.hitsz.prop.PropBomb;

/**
 * @author xyhstart
 * @create 2022-03-22 21:43
 */
public class PropBombFactory extends BasePropFactory {

    /**
     * PropBombFactory子列工厂方法返回PropBomb对象
     * @param locationX 道具x坐标
     * @param locationY 道具y坐标
     * @param speedY 道具速度speedY
     * @return PropBomb实例
     */
    @Override
    public AbstractProp createProp(int locationX, int locationY, int speedY) {
        return new PropBomb(locationX, locationY, speedY);
    }
}
