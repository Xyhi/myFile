package edu.hitsz.panel;

import edu.hitsz.DAO.Data;
import edu.hitsz.DAO.DataDAOImpl;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-04-22 9:06
 */
public class BoardPanel {
    private JPanel MainPanel;
    private JPanel topPanel;
    private JPanel bottomPanel;
    private JScrollPane tableScrollPane;
    private JLabel headerLabel;
    private JTable scoreTable;
    private JButton deleteButton;

    public BoardPanel(){
        //设置文字居中
        DefaultTableCellRenderer dc = new DefaultTableCellRenderer();
        dc.setHorizontalAlignment(SwingConstants.CENTER);
        scoreTable.setDefaultRenderer(Object.class, dc);

        //遍历所有dataDAO,将数据传入到table中
        String[] columnName = {"名次", "玩家名", "得分", "记录时间"};
        DataDAOImpl dataDAO = new DataDAOImpl();
        String[][] tableData = {{}};
        try {
            List<Data> dataList = dataDAO.getAllData();
            if(dataList != null) {
                int len = dataList.size();
                int wid = columnName.length;
                tableData = new String[len][wid];
                dataList.sort((o1, o2) -> o2.getScore() - o1.getScore());
                for (int i = 0; i < dataList.size(); i++) {
                    String[] temp = dataList.get(i).getDataStr();
                    tableData[i][0] = Integer.toString(i + 1);
                    System.arraycopy(temp, 0, tableData[i], 1, temp.length);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        DefaultTableModel model = new DefaultTableModel(tableData, columnName){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        scoreTable.setModel(model);
        tableScrollPane.setViewportView(scoreTable);

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    List<Data> dataList = dataDAO.getAllData();
                    if(dataList != null) {
                        dataList.sort((o1, o2) -> o2.getScore() - o1.getScore());
                        int row = scoreTable.getSelectedRow();
                        //通过id删除相应数据
                        long id = (dataList.get(row)).getId();
                        //弹出消息对话框，判断是否确定删除
                        int n = JOptionPane.showConfirmDialog(null, "是否确定删除选择选中的玩家", "选择一个选项",JOptionPane.YES_NO_OPTION);
                        if(n == 0) {
                            model.removeRow(row);
                            dataDAO.deleteData(id);
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("BoardPanel");
        frame.setContentPane(new BoardPanel().MainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getMainPanel() {
        return MainPanel;
    }
}
