package edu.hitsz.factory;

import edu.hitsz.prop.AbstractProp;
import edu.hitsz.prop.PropBlood;

/**
 * @author xyhstart
 * @create 2022-03-22 21:43
 */
public class PropBloodFactory extends BasePropFactory {

    /**
     * PropBloodFactory子类工厂方法创造PropBlood对象
     * @param locationX 道具x坐标
     * @param locationY 道具y坐标
     * @param speedY 道具速度speedY
     * @return PropBlood实例
     */
    @Override
    public AbstractProp createProp(int locationX, int locationY, int speedY) {
        return new PropBlood(locationX, locationY, speedY);
    }
}
