package edu.hitsz.factory;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.MobEnemy;
import edu.hitsz.application.ImageManager;
import edu.hitsz.application.Main;

/**
 * @author xyhstart
 * @create 2022-03-22 21:24
 */
public class MobEnemyFactory extends BaseEnemyFactory {
    int locationX = (int) (Math.random() * (Main.WINDOW_WIDTH - ImageManager.MOB_ENEMY_IMAGE.getWidth())) * 1;
    int locationY = (int) (Math.random() * Main.WINDOW_HEIGHT * 0.2) * 1;
    int speedX = 0;
    int speedY = 10;
    int hp = 30;

    /**
     * MobEnemyFactory子类工厂方法返回MobEnemy对象
     * @return MobEnemy实例
     */
    @Override
    public AbstractAircraft createEnemy() {
        return new MobEnemy(locationX,
                locationY,
                speedX,
                speedY,
                hp);
    }
}
