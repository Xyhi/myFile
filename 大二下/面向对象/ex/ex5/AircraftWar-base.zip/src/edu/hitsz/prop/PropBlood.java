package edu.hitsz.prop;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.HeroAircraft;

/**
 * @author xyhstart
 * @create 2022-03-15 8:54
 */
public class PropBlood extends AbstractProp{

    private int increase = 100;  // 加血道具每次增加的血量

    public PropBlood(int locationX, int locationY, int speedY) {
        super(locationX, locationY, speedY);
    }

    /**
     * 加血道具,实现HeroAircraft的加血功能
     * @param abstractAircrafts
     */
    @Override
    public void function(AbstractAircraft... abstractAircrafts) {
        if(abstractAircrafts[0] instanceof HeroAircraft) {
            HeroAircraft heroAircraft =(HeroAircraft)abstractAircrafts[0];
            int curBlood = heroAircraft.getHp();
            int maxHp = heroAircraft.getMaxHp();
            if (curBlood < maxHp) {
                heroAircraft.increaseHp(increase);
                // 打印语句进行功能测试
                System.out.println("Blood active!");
                System.out.println("HeroAircraft's Hp is " + heroAircraft.getHp());
            } else {
                System.out.println("Blood has reached the maximum");
            }
        }
        //功能实现后销毁
        vanish();
    }

    public int getIncrease(){
        return increase;
    }
}
