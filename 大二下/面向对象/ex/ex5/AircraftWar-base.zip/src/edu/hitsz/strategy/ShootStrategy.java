package edu.hitsz.strategy;

import edu.hitsz.bullet.BaseBullet;

import java.util.List;

/**
 * @author xyhstart
 * @create 2022-04-08 21:22
 */
public interface ShootStrategy {
    List<BaseBullet> shoot(Class<? extends BaseBullet> bulletClass, int locationX, int locationY, int shootNum, int direction, int power);
}
