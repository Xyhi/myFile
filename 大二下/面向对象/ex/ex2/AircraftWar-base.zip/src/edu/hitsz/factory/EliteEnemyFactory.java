package edu.hitsz.factory;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.EliteEnemy;

/**
 * @author xyhstart
 * @create 2022-03-22 21:25
 */
public class EliteEnemyFactory extends EnemyFactory{

    // 工厂方法返回EliteEnemy对象
    @Override
    public AbstractAircraft createEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        return new EliteEnemy(locationX, locationY, speedX, speedY, hp);
    }
}
