package edu.hitsz.factory;

import edu.hitsz.prop.AbstractProp;
import edu.hitsz.prop.PropBlood;
import edu.hitsz.prop.PropBomb;

/**
 * @author xyhstart
 * @create 2022-03-22 21:43
 */
public class PropBloodFactory extends PropFactory{

    // 工厂方法创造PropBlood对象
    @Override
    public AbstractProp createProp(int locationX, int locationY, int speedY) {
        return new PropBlood(locationX, locationY, speedY);
    }
}
