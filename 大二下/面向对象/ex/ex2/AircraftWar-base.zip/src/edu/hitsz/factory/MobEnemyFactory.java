package edu.hitsz.factory;

import edu.hitsz.aircraft.AbstractAircraft;
import edu.hitsz.aircraft.MobEnemy;

/**
 * @author xyhstart
 * @create 2022-03-22 21:24
 */
public class MobEnemyFactory extends EnemyFactory{

    // 工厂方法返回MobEnemy对象
    @Override
    public AbstractAircraft createEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        return new MobEnemy(locationX, locationY, speedX, speedY, hp);
    }
}
