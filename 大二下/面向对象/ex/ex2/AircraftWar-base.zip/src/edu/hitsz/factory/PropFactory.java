package edu.hitsz.factory;

import edu.hitsz.prop.AbstractProp;

/**
 * @author xyhstart
 * @create 2022-03-22 21:42
 */
abstract public class PropFactory {

    // 工厂方法创造道具对象
    public abstract AbstractProp createProp(int locationX, int locationY, int speedY);
}
