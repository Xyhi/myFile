package edu.hitsz.aircraft;

import edu.hitsz.bullet.BaseBullet;
import edu.hitsz.bullet.EnemyBullet;
import edu.hitsz.factory.PropFactory;

import java.util.LinkedList;
import java.util.List;

/**
 * @author xyhstart
 * @create 2022-03-15 7:25
 */
public class BossEnemy extends AbstractAircraft{

    private int power = 40;    // 子弹伤害
    private int direction = 2; // 子弹射击方向
    private int shootNum = 3;  // Boss机一次发射子弹数目


    // Boss机构造方法
    public BossEnemy(int locationX, int locationY, int speedX, int speedY, int hp) {
        super(locationX, locationY, speedX, speedY, hp);
    }

    /**
     * BOSS机发射子弹功能
     * 考虑到BOSS机的射击方式，我们一次返回一定数目且方向不同的子弹
     * 同时为了游戏的趣味性，可以再后续增添更多的射击方式
     * @return
     */
    @Override
    public List<BaseBullet> shoot() {
       return new LinkedList<>();
    }
}
