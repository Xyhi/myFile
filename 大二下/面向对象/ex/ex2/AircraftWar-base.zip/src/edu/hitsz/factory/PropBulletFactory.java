package edu.hitsz.factory;


import edu.hitsz.prop.AbstractProp;
import edu.hitsz.prop.PropBullet;

/**
 * @author xyhstart
 * @create 2022-03-22 21:43
 */
public class PropBulletFactory extends PropFactory {

    // 工厂方法返回PropBullet对象
    @Override
    public AbstractProp createProp(int locationX, int locationY, int speedY) {
        return new PropBullet(locationX, locationY, speedY);
    }
}
